class ProjectResourceController < ApplicationController
  before_filter :project
end
