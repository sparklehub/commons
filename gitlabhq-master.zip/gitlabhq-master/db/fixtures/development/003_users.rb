User.seed(:id, [
  { id: 2, username: Faker::Internet.user_name, name: Faker::Name.name, email: Faker::Internet.email},
  { id: 3, username: Faker::Internet.user_name, name: Faker::Name.name, email: Faker::Internet.email},
  { id: 4, username: Faker::Internet.user_name, name: Faker::Name.name, email: Faker::Internet.email},
  { id: 5, username: Faker::Internet.user_name, name: Faker::Name.name, email: Faker::Internet.email},
  { id: 6, username: Faker::Internet.user_name, name: Faker::Name.name, email: Faker::Internet.email},
  { id: 7, username: Faker::Internet.user_name, name: Faker::Name.name, email: Faker::Internet.email},
  { id: 8, username: Faker::Internet.user_name, name: Faker::Name.name, email: Faker::Internet.email},
  { id: 9, username: Faker::Internet.user_name, name: Faker::Name.name, email: Faker::Internet.email}
])

