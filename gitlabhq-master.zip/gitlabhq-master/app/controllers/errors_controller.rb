class ErrorsController < ApplicationController
  def githost
    render "errors/gitolite"
  end
end
