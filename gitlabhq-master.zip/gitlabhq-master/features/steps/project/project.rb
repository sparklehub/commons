class Projects < Spinach::FeatureSteps
  include SharedAuthentication
  include SharedProject
  include SharedPaths
end
