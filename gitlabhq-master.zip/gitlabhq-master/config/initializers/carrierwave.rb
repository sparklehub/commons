CarrierWave::SanitizedFile.sanitize_regexp = /[^[:word:]\.\-\+]/
