# GIT over HTTP
require Rails.root.join("lib", "gitlab", "backend", "grack_auth")

# GITOLITE backend
require Rails.root.join("lib", "gitlab", "backend", "gitolite")
