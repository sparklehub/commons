class Admin::ResqueController < AdminController
  def show
  end
end
