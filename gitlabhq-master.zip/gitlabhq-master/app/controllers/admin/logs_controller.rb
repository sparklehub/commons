class Admin::LogsController < AdminController
end
